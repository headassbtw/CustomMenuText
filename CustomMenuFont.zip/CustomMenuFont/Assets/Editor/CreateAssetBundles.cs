﻿using UnityEditor;
using System.IO;
using System.Linq;
using TMPro;
using System;
using UnityEngine;
using UnityEngine.TextCore;
using UnityEngine.TextCore.LowLevel;
using System.Collections;
using System.Collections.Generic;

public class CreateAssetBundles
{
    public class BuilderWindow : EditorWindow
    {
        [MenuItem("CustomMenuText/AssetBundle Builder")]
        static void Init()
        {
            BuilderWindow window = (BuilderWindow)EditorWindow.GetWindow(typeof(BuilderWindow), false, "Font Builder");
            window.Show();
        }
        private string BundleName = "";
        private void OnGUI()
        {
            GUILayout.Label("Font Builder", EditorStyles.boldLabel);
            GUILayout.Label("Font Name", EditorStyles.label);
            BundleName = GUILayout.TextField(BundleName);
            if (GUILayout.Button("Export " + BundleName))
            {
                string path = EditorUtility.SaveFilePanel("Save font file", "", BundleName + "", "");

                if (!string.IsNullOrEmpty(path))
                {
                    AssetBundleBuild fontbuild = new AssetBundleBuild();
                    fontbuild.assetBundleName = Path.GetFileName(path);
                    fontbuild.assetNames = new string[]
                    {
                                "Assets/Text.prefab"
                    };
                    BuildTargetGroup buildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
                    BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;
                    BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { fontbuild }, 0, EditorUserBuildSettings.activeBuildTarget);
                    try
                    {
                        File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                    }
                    catch (IOException)
                    {
                        File.Delete(path);
                        File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                    }
                    AssetDatabase.Refresh();
                    EditorUtility.DisplayDialog("Export Successful!", "yeet!", "OK");
                }
                else
                {
                    EditorUtility.DisplayDialog("Export Failed!", "ya fucked up idk", "REE");
                }
            }
        }
    }
    public class OneClickWindow : EditorWindow
    {
        [MenuItem("CustomMenuText/Font Converter")]
        static void Init()
        {
            OneClickWindow window = (OneClickWindow)EditorWindow.GetWindow(typeof(OneClickWindow), false, "Font Converter");
            window.Show();
        }

        public static Font Fawnt = null;
        public static bool advancedAtlas = false;
        public static int SamplingPointSize = 821;
        public static int AtlasPadding = 9;
        public static bool build = true;
        public static bool idiot = false;
        public static Vector2Int AtlasResolution = new Vector2Int(2048, 2048);

        public static TMP_FontAsset fFont;

        private void OnGUI()
        {
            GUILayout.Label("Font Converter", EditorStyles.boldLabel);


            GUILayout.Label("THIS DOES NOT WORK IN ITS CURRENT STATE,\nDO NOT COMPLAIN,\nTHIS IS ONLY HERE BECAUSE I CAN'T BE ASSED\nTO KEEP IT PRIVATE\nalso help pls", EditorStyles.boldLabel);
            idiot = GUILayout.Toggle(idiot, "I am aware");

            if (idiot)
            {
                Fawnt = (Font)EditorGUILayout.ObjectField("Font File", Fawnt, typeof(Font), false);

                advancedAtlas = GUILayout.Toggle(advancedAtlas, "Atlas Options");
                if (advancedAtlas)
                {
                    AtlasResolution = EditorGUILayout.Vector2IntField("Atlas Resolution", AtlasResolution);
                    AtlasPadding = EditorGUILayout.IntField("Atlas Padding", AtlasPadding);
                    SamplingPointSize = EditorGUILayout.IntField("Sampling Point Size", SamplingPointSize);
                }

                if (Fawnt)
                {

                    build = GUILayout.Toggle(build, "Build Font");
                    if (GUILayout.Button("Export Font"))
                    {
                        string path = EditorUtility.SaveFilePanel("Save font file", "", Fawnt.fontNames.ElementAt(0) + "", "");
                        if (!string.IsNullOrEmpty(path))
                        {
                            fFont = ScriptableObject.CreateInstance<TMP_FontAsset>();
                            AssetDatabase.CreateAsset(fFont, "Assets/TMPFonts/" + Fawnt.fontNames.ElementAt(0) + ".asset");


                            var fuck = new FontAssetCreationSettings()
                            {

                            };

                            // Set face information
                            FontEngine.InitializeFontEngine();
                            FontEngine.LoadFontFace(Fawnt, 90);
                            // Set font reference and GUID
                            fFont.atlasPopulationMode = AtlasPopulationMode.Dynamic;


                            fFont.atlasTextures = new Texture2D[1];

                            // Create atlas texture of size zero.
                            Texture2D texture = new Texture2D(0, 0, TextureFormat.Alpha8, false);

                            texture.name = Fawnt.fontNames.ElementAt(0) + " Atlas";
                            fFont.atlasTextures[0] = texture;
                            AssetDatabase.AddObjectToAsset(texture, fFont);

                            // Create new Material and Add it as Sub-Asset
                            Shader default_Shader = Shader.Find("TextMeshPro/Distance Field");
                            Material tmp_material = new Material(default_Shader);

                            tmp_material.name = texture.name + " Material";
                            tmp_material.SetTexture(ShaderUtilities.ID_MainTex, texture);
                            tmp_material.SetFloat(ShaderUtilities.ID_TextureWidth, AtlasResolution.x);
                            tmp_material.SetFloat(ShaderUtilities.ID_TextureHeight, AtlasResolution.y);

                            tmp_material.SetFloat(ShaderUtilities.ID_WeightNormal, fFont.normalStyle);
                            tmp_material.SetFloat(ShaderUtilities.ID_WeightBold, fFont.boldStyle);

                            fFont.material = tmp_material;

                            AssetDatabase.AddObjectToAsset(tmp_material, fFont);


                            new FontAssetCreationSettings
                            {
                                sourceFontFileName = Fawnt.fontNames.ElementAt(0),
                                pointSize = fFont.faceInfo.pointSize,
                                padding = AtlasPadding,
                                atlasHeight = AtlasResolution.y,
                                atlasWidth = AtlasResolution.x,

                            };

                            // Not sure if this is still necessary in newer versions of Unity.
                            EditorUtility.SetDirty(fFont);

                            AssetDatabase.SaveAssets();






                            GameObject text = GameObject.Find("Text");
                            if (text == null)
                            {
                                try
                                {
                                    text = (GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath("Assets/Text.prefab", typeof(GameObject)));
                                }
                                catch (ArgumentException)
                                {
                                    EditorUtility.DisplayDialog("Missing Prefab", "Text prefab is missing, named wrong, or otherwise where it shouldn't be. \nPut the prefab in \"Assets/Text.prefab\" or redownload the Unity project.", "OK");
                                    throw new NullReferenceException();
                                }
                            }
                            /*if (text.GetComponent<TextMeshPro>())
                            {
                                DestroyImmediate(text.GetComponent<TextMeshPro>());
                            }
                            var tmp = text.AddComponent<TextMeshPro>();
                            */
                            var tmp = text.GetComponent<TextMeshPro>();
                            //tmp.font = fFont;
                            tmp.text = "Beat";
                            //tmp.alignment = TextAlignmentOptions.Center;
                            tmp.fontSize = 24;


                            PrefabUtility.SaveAsPrefabAsset(text, "Assets/Temp/Temp.prefab");

                            //PrefabUtility.ApplyPrefabInstance(text, InteractionMode.AutomatedAction);



                            if (build)
                            {

                                AssetBundleBuild fontbuild = new AssetBundleBuild();
                                fontbuild.assetBundleName = Path.GetFileName(path);
                                fontbuild.assetNames = new string[]
                                {
                                "Assets/TMPFonts/" + Fawnt.fontNames.ElementAt(0) + ".asset",
                                "Assets/Temp/Temp.prefab"
                                };
                                BuildTargetGroup buildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
                                BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;
                                BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { fontbuild }, 0, EditorUserBuildSettings.activeBuildTarget);
                                try
                                {
                                    File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                                }
                                catch (IOException)
                                {
                                    File.Delete(path);
                                    File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                                }
                                AssetDatabase.Refresh();
                                EditorUtility.DisplayDialog("Export Successful!", "yeet!", "OK");
                            }
                        }
                        else
                        {
                            EditorUtility.DisplayDialog("Export Failed!", "Path is invalid.", "OK");
                        }
                    }
                }
            }
        }
    }
    
}