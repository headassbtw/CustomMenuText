﻿using UnityEditor;
using System.IO;
using System.Linq;
using TMPro;
using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CreateAssetBundles
{
    public class NotifWindow : EditorWindow
    {
        [MenuItem("CustomMenuText/Font Converter")]
        static void Init()
        {
            NotifWindow window = (NotifWindow)EditorWindow.GetWindow(typeof(NotifWindow), false, "Font Converter");
            window.Show();
        }

        public static Font Fawnt = null;
        public static bool advancedAtlas = false;
        public static int SamplingPointSize = 821;
        public static int AtlasPadding = 9;
        public static Vector2Int AtlasResolution = new Vector2Int(2048, 2048);


        private void OnGUI()
        {
            GUILayout.Label("Font Converter", EditorStyles.boldLabel);
            Fawnt = (Font)EditorGUILayout.ObjectField("Font File", Fawnt, typeof(Font), false);
            
            advancedAtlas = GUILayout.Toggle(advancedAtlas, "Atlas Options");
            if (advancedAtlas)
            {
                AtlasResolution = EditorGUILayout.Vector2IntField("Atlas Resolution", AtlasResolution);
                AtlasPadding = EditorGUILayout.IntField("Atlas Padding", AtlasPadding);
                SamplingPointSize = EditorGUILayout.IntField("Sampling Point Size", SamplingPointSize);
            }

            if (Fawnt)
            {
                if (GUILayout.Button("Export Font"))
                {
                    string path = EditorUtility.SaveFilePanel("Save font file", "", Fawnt.fontNames.ElementAt(0) + ".cmtfont", "cmtfont");
                    if (!string.IsNullOrEmpty(path))
                    {
                        TMP_FontAsset Font = TMP_FontAsset.CreateFontAsset(Fawnt, SamplingPointSize, AtlasPadding, UnityEngine.TextCore.LowLevel.GlyphRenderMode.SDFAA, AtlasResolution.x, AtlasResolution.y);
                        Font.ReadFontAssetDefinition();
                        AssetDatabase.CreateAsset(Font, "Assets/TMPFonts/" + Fawnt.fontNames.ElementAt(0) + ".asset");

                        GameObject text = GameObject.Find("Text");
                        if(text == null)
                        {
                            try
                            {
                                
                                text = (GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath("Assets/Text.prefab", typeof(GameObject)));
                            }
                            catch(ArgumentException)
                            {
                                EditorUtility.DisplayDialog("Missing Prefab", "Text prefab is missing, named wrong, or otherwise where it shouldn't be. \nPut the prefab in \"Assets/Text.prefab\" or redownload the Unity project.", "OK");
                                throw new NullReferenceException();
                            }
                        }
                        if (text.GetComponent<TextMeshPro>())
                        {
                            DestroyImmediate(text.GetComponent<TextMeshPro>());
                        }
                        var tmp = text.AddComponent<TextMeshPro>();
                        tmp.font = Font;
                        tmp.material = Font.material;
                        tmp.text = "Beat";
                        tmp.alignment = TextAlignmentOptions.Center;
                        tmp.fontSize = 24;
                        
                        PrefabUtility.ApplyPrefabInstance(text, InteractionMode.AutomatedAction);
                        AssetBundleBuild fontbuild = new AssetBundleBuild();
                        fontbuild.assetBundleName = Path.GetFileName(path);
                        fontbuild.assetNames = new string[]
                        {
                            "Assets/Text.prefab"
                        };
                        BuildTargetGroup buildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
                        BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;
                        BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { fontbuild }, 0, EditorUserBuildSettings.activeBuildTarget);
                        try
                        {
                            File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                        }
                        catch (IOException)
                        {
                            File.Delete(path);
                            File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                        }
                        AssetDatabase.Refresh();
                        EditorUtility.DisplayDialog("Export Successful!", "yeet!", "OK");
                    }
                    else
                    {
                        EditorUtility.DisplayDialog("Export Failed!", "Path is invalid.", "OK");
                    }
                }
            }
        }
    }
    
}