﻿using UnityEditor;
using System.IO;
using System.Linq;
using TMPro;
using System;
using UnityEngine;
using UnityEngine.TextCore;
using UnityEngine.TextCore.LowLevel;
using System.Collections;
using System.Collections.Generic;

[InitializeOnLoad]
public class CreateAssetBundles
{
    static CreateAssetBundles()
    {
        EditorApplication.update += OnLoaded;
    }

    static void OnLoaded()
    {
        EditorApplication.update -= OnLoaded;

        HelpWindow.Awake();
    }

    public class HelpWindow : EditorWindow
    {
        [MenuItem("CustomMenuText/Help", false, 0)]
        public static void Awake()
        {
            HelpWindow window = (HelpWindow)EditorWindow.GetWindow(typeof(HelpWindow), false, "Help");
            if (!window)
                window = (HelpWindow)ScriptableObject.CreateInstance("HelpWindow");
            window.minSize = new Vector2(450, 340);
            window.Show();
        }
        public void OnGUI()
        {
            var gs = new GUIStyle()
            {
                wordWrap = true
            };
            Texture2D readthis = (Texture2D)AssetDatabase.LoadAssetAtPath("Assets/Editor/readthis.png", typeof(Texture2D));
            GUI.DrawTexture(new Rect(0, 0, 450, 90), readthis);
            GUILayout.Space(80f);
            GUILayout.Label("Basics", EditorStyles.boldLabel);
            GUILayout.Label("To start, drag in a font file (usually ttf) and use the OneClick™ font converter to create your font", gs);
            if (GUILayout.Button("Open OneClick™ font converter"))
                OneClickWindow.Awake();
            GUILayout.Label("", EditorStyles.largeLabel);
            GUILayout.Label("Other tools", EditorStyles.largeLabel);
            GUILayout.Label("Font Builder", EditorStyles.boldLabel);
            GUILayout.Label("The font builder is an automated tool to take Pre-existing TextMeshPro fonts and export them. Use this if you want to edit the font in some way.", gs);
            if (GUILayout.Button("Open Font Builder"))
                FontBuilderWindow.Init();
            GUILayout.Label("AssetBundle Builder", EditorStyles.boldLabel);
            GUILayout.Label("The AssetBundle builder is a semi-automated tool to build an AssetBundle, and export it to a specific path. Use this if you're doing something really weird.", gs);
            if (GUILayout.Button("Open AssetBundle Builder"))
                BuilderWindow.Init();
        }
    }
    public class OneClickWindow : EditorWindow
    {
        [MenuItem("CustomMenuText/OneClick™ Font Converter", false, 0)]
        public static void Awake()
        {
            window = (OneClickWindow)EditorWindow.GetWindow(typeof(OneClickWindow), false, "Font Converter");
            window.Show();
        }
        public static OneClickWindow window;
        public static Font Fawnt = null;

        public static TMP_FontAsset fFont;

        private void OnGUI()
        {
            GUILayout.Label("Font Converter", EditorStyles.boldLabel);
            Fawnt = (Font)EditorGUILayout.ObjectField("Font File", Fawnt, typeof(Font), false);
            if (Fawnt)
            {
                if (GUILayout.Button("Export " + Fawnt.fontNames.ElementAt(0)))
                {
                    string path = EditorUtility.SaveFilePanel("Save font file", "", Fawnt.fontNames.ElementAt(0) + "", "");
                    if (!string.IsNullOrEmpty(path))
                    {
                        //selects the font we selected from the list
                        Selection.activeObject = Fawnt;

                        string CharactersOnMyKeyboard = "abcdefghijklmnopqrstuvwxyx~`!1@2#3$4%5^6&7*8(9)0_-+={[}]|\\:;\"'<,>.?/";


                        //getting paths for the font we selected
                        string sourceFontFilePath = AssetDatabase.GetAssetPath(Fawnt);
                        string folderPath = Path.GetDirectoryName(sourceFontFilePath);
                        string assetName = Path.GetFileNameWithoutExtension(sourceFontFilePath);

                        //checks to see if there's already an existing TextMeshPro font 
                        TMP_FontAsset tmpFont = (TMP_FontAsset)AssetDatabase.LoadAssetAtPath(folderPath + "/" + assetName + " SDF.asset", typeof(TMP_FontAsset));

                        //if there isn't, create one
                        if (!tmpFont)
                        {
                            TMP_FontAsset_CreationMenu.CreateFontAsset();
                            tmpFont = (TMP_FontAsset)AssetDatabase.LoadAssetAtPath(folderPath + "/" + assetName + " SDF.asset", typeof(TMP_FontAsset));
                        }
                        #region old jank
                        //makes sure the atlas is complete, by adding every character on my keyboard
                        /*var missing = new List<char>();
                        if (tmpFont.HasCharacters(CharactersOnMyKeyboard, out missing))
                            Debug.Log("All characters are present in the atlas.");
                        string missings = "";
                        if (missing == null)
                            Debug.LogError("Missing character list is null!");
                        Debug.LogWarning("Font atlas has " + missing.Count.ToString() + " missing characters!");
                        foreach (var missingchar in missing)
                        {
                            missings += missingchar.ToString();
                        }
                        List<uint> chars = new List<uint>();
                        foreach(var charinf in Fawnt.characterInfo)
                        {
                            chars.Add(Convert.ToUInt32(charinf.index));
                        }
                        var chars2 = chars.ToArray();

                        tmpFont.TryAddCharacters(chars2);
                        */
                        #endregion

                        //finds the text prefab
                        GameObject text = GameObject.Find("Text");
                        if (text == null)
                        {
                            try
                            {
                                text = (GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath("Assets/Text.prefab", typeof(GameObject)));
                            }
                            catch (ArgumentException)
                            {
                                EditorUtility.DisplayDialog("Missing Prefab", "Text prefab is missing, named wrong, or otherwise where it shouldn't be. \nPut the prefab in \"Assets/Text.prefab\" or redownload the Unity project.", "OK");
                                throw new NullReferenceException();
                            }
                        }
                        //gets the TMP component, and edits the settings on it
                        var tmp = text.GetComponent<TextMeshPro>();
                        //this is so that the atlas has characters on it, don't question it too hard
                        tmp.text = CharactersOnMyKeyboard;
                        tmp.font = tmpFont;
                        tmp.alignment = TextAlignmentOptions.Center;
                        tmp.fontSize = 24;

                        //creates a temp folder, and exports the edited prefab there (as to not touch the existing one)
                        if (!AssetDatabase.IsValidFolder("Assets/Temp"))
                            AssetDatabase.CreateFolder("Assets", "Temp");
                        PrefabUtility.SaveAsPrefabAsset(text, "Assets/Temp/Text.prefab");
                        #region building
                        //create the settings for building the AssetBundle
                        AssetBundleBuild fontbuild = new AssetBundleBuild();
                        fontbuild.assetBundleName = Path.GetFileName(path);
                        fontbuild.assetNames = new string[]
                        {
                                "Assets/Temp/Text.prefab",
                                folderPath + "/" + assetName + " SDF.asset"
                        };
                        BuildTargetGroup buildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
                        BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;
                        //builds it
                        BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { fontbuild }, 0, EditorUserBuildSettings.activeBuildTarget);
                        //tries to move it to the new location
                        try
                        {
                            try
                            {
                                File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                            }
                            //if it can't (probably an existing file with the same name) it deletes and tries again
                            catch (IOException)
                            {
                                File.Delete(path);
                                File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                            }
                            //deletes the temp prefab, and refreshes the asset database
                            AssetDatabase.DeleteAsset("Assets/Temp/Text.prefab");
                            AssetDatabase.Refresh();
                            tmp.text = "Beat";
                            EditorUtility.DisplayDialog("Export Successful!", "yeet!", "OK");
                        }
                        catch (FileNotFoundException)
                        {
                            EditorUtility.DisplayDialog("Export Failed", "This happens for some reason, just try again", "OK");
                        }
                        #endregion
                    }
                    else
                    {
                        EditorUtility.DisplayDialog("Export Failed!", "Path is invalid.", "OK");
                    }
                }
            }
        }
    }
    public class FontBuilderWindow : EditorWindow
    {
        [MenuItem("CustomMenuText/Other Tools/Font Builder", false, 1)]
        public static void Init()
        {
            FontBuilderWindow window = (FontBuilderWindow)EditorWindow.GetWindow(typeof(FontBuilderWindow), false, "Font Builder");
            window.Show();
        }
        private TMP_FontAsset tmpFont;
        private string name = "";
        private void OnGUI()
        {
            

            GUILayout.Label("Font Builder", EditorStyles.boldLabel);
            #pragma warning disable CS0618 // Shut the fuck up
            tmpFont = (TMP_FontAsset)EditorGUILayout.ObjectField("Font", tmpFont, typeof(TMP_FontAsset));
            #pragma warning restore CS0618 // Shut the fuck up
            try
            {
                name = tmpFont.sourceFontFile.fontNames.ElementAt(0);
            }
            catch (Exception)
            {
                name = tmpFont.name;
            }
            if (tmpFont)
            {
                if (GUILayout.Button("Export " + name))
                {
                    GameObject text = GameObject.Find("Text");
                    if (text == null)
                    {
                        try
                        {
                            text = (GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath("Assets/Text.prefab", typeof(GameObject)));
                        }
                        catch (ArgumentException)
                        {
                            EditorUtility.DisplayDialog("Missing Prefab", "Text prefab is missing, named wrong, or otherwise where it shouldn't be. \nPut the prefab in \"Assets/Text.prefab\" or redownload the Unity project.", "OK");
                            throw new NullReferenceException();
                        }
                    }

                    TextMeshPro tmpText = text.GetComponent<TextMeshPro>();
                    tmpText.font = tmpFont;
                    tmpText.UpdateFontAsset();
                    AssetDatabase.CreateFolder("Assets", "Temp");
                    PrefabUtility.SaveAsPrefabAsset(text, "Assets/Temp/Text.prefab");

                    string path = EditorUtility.SaveFilePanel("Save font file", "", name + "", "");

                    if (!string.IsNullOrEmpty(path))
                    {
                        
                        AssetBundleBuild fontbuild = new AssetBundleBuild();
                        fontbuild.assetBundleName = Path.GetFileName(path);
                        fontbuild.assetNames = new string[]
                        {
                                "Assets/Temp/Text.prefab"
                        };
                        BuildTargetGroup buildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
                        BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;
                        BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { fontbuild }, 0, EditorUserBuildSettings.activeBuildTarget);
                        try
                        {
                            File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                        }
                        catch (IOException)
                        {
                            File.Delete(path);
                            File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                        }
                        AssetDatabase.Refresh();
                        AssetDatabase.DeleteAsset("Assets/Temp/Text.prefab");
                        EditorUtility.DisplayDialog("Export Successful!", "yeet!", "OK");
                    }
                    else
                    {
                        EditorUtility.DisplayDialog("Export Failed!", "ya fucked up idk", "REE");
                    }

                }
            }
        }
    }
    public class BuilderWindow : EditorWindow
    {
        [MenuItem("CustomMenuText/Other Tools/AssetBundle Builder", false, 2)]
        public static void Init()
        {
            BuilderWindow window = (BuilderWindow)EditorWindow.GetWindow(typeof(BuilderWindow), false, "AssetBundle Builder");
            window.Show();
        }
        private static GameObject prefab;
        private string BundleName = "";
        private void OnGUI()
        {
            GUILayout.Label("AssetBundle Builder", EditorStyles.boldLabel);
            GUILayout.Label("Name", EditorStyles.label);
            BundleName = GUILayout.TextField(BundleName);
            prefab = (GameObject)EditorGUILayout.ObjectField("Prefab", prefab, typeof(GameObject), false);

            if (GUILayout.Button("Export " + BundleName))
            {
                string path = EditorUtility.SaveFilePanel("Save font file", "", BundleName + "", "");

                if (!string.IsNullOrEmpty(path))
                {
                    AssetBundleBuild fontbuild = new AssetBundleBuild();
                    fontbuild.assetBundleName = Path.GetFileName(path);
                    fontbuild.assetNames = new string[]
                    {
                                AssetDatabase.GetAssetPath(prefab)
                    };
                    BuildTargetGroup buildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
                    BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;
                    BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { fontbuild }, 0, EditorUserBuildSettings.activeBuildTarget);
                    try
                    {
                        File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                    }
                    catch (IOException)
                    {
                        File.Delete(path);
                        File.Move(Path.Combine(Application.temporaryCachePath, Path.GetFileName(path)), path);
                    }
                    AssetDatabase.Refresh();
                    EditorUtility.DisplayDialog("Export Successful!", "yeet!", "OK");
                }
                else
                {
                    EditorUtility.DisplayDialog("Export Failed!", "ya fucked up idk", "REE");
                }
            }
        }
    }
    
    
}